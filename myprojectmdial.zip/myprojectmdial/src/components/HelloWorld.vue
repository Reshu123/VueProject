<template>
  <div class="container">
    <div class="holder">
      <ul>
        <li v-for="(data, index) in contacts" :key='index'>{{data.contact}}

           <div id="">
  <button v-on:click= "greet">Know me more!!  

  </button>

</div>
        </li>
       
      </ul>
     
      
    </div>
  </div>
</template>


<script>

export default {
 
  data() {
    return {
      contacts:   [
          { "contact": "Rhiannon Lara" },
          { "contact": "Hayes Keth" },
          { "contact": "Gretchen H.Olsen"  },
          { "contact": "Kaira X. Jordan" },
          { "contact": "Travis Price" }
      ],
      bgColor: 'yellow',
      bgWidth: '100%',
      bgHeight: '30px'
    }
  }
}
  
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

  .holder {
    background: #fff;
  }

  ul {
    margin: 0;
    padding: 0;
    list-style-type: none;
  }
  
  ul li  {
    padding: 20px;
    font-size: 1.3em;
    background-color: #E0EDF4;
    border-left: 5px solid #3EB3F6;
    margin-bottom: 2px;
    color: #3E5252;
  }

  button{
    padding: 5px;
    background-color:5px solid #3EB3F6;
    color: rgb(71, 62, 82);
  }

  p  {
    text-align:center;
    padding: 30px 0;
    color: gray;
  }

  .container {
    box-shadow: 0px 0px 40px lightgray;
  }

</style>