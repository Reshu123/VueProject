	<template>
    <div id="contact-form" class="contact-form">
		<h1 class="contact-form_title">Contact Form</h1>
		<div class="separator"></div>

		<form class="form" @submit="onSubmit">
      <input required name="name required" v-model='contact.name' placeholder="name" type="name" autocomplete="off">
      <input required name="id" v-model='contact.id' placeholder="id" type="number" autocomplete="off">
			<input required name="email" v-model='contact.email' placeholder="email" type="email" autocomplete="off">
			<input required name="phonenumber" v-model="contact.phonenumber" placeholder="phonenumber" type="number" autocomplete="off">
			
		</form>
	</div>
</template>


<script>
export default {
 
  data() {
    return {
      contacts:   [
          { "name": "Rhiannon Lara" , "email":"rhiannon_lara@gmail.com " ,"is_favorite": true, "phone": "801-555-3213" },
          { "contact": "Hayes Keth", "email":"hayesketh@gmail.com " ,"is_favorite": true, "phone": "801-895-8756" },
          { "contact": "Gretchen H.Olsen" ,"email":"gretchenh111@gmail.com " ,"is_favorite": true, "phone": "356-555-8932"},
          { "contact": "Kaira X. Jordan", "email":"kairaX@gmail.com " ,"is_favorite": true, "phone": "978-956-3213"},
          { "contact": "Travis Price","email":"tp@gmail.com " ,"is_favorite": true, "phone": "098-235-3213" }
      ],
      bgColor: 'yellow',
      bgWidth: '100%',
      bgHeight: '30px'
    }
  }
}
</script>

<style scoped>

  .holder {
    background: #fff;
  }

  ul {
    margin: 0;
    padding: 0;
    list-style-type: none;
  }
  
  ul li  {
    padding: 20px;
    font-size: 1.3em;
    background-color: #E0EDF4;
    border-left: 5px solid #3EB3F6;
    margin-bottom: 2px;
    color: #3E5252;
  }

  button{
    padding: 5px;
    background-color:5px solid #3EB3F6;
    color: rgb(71, 62, 82);
  }

  p  {
    text-align:center;
    padding: 30px 0;
    color: gray;
  }

  .container {
    box-shadow: 0px 0px 40px lightgray;
  }

</style>
    
